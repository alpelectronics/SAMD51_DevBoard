#define UF2_VERSION_BASE "v3.10.0-7-ga29db5a"
